# Week3 Forms and more templates
This is a fairly easy week.  Follow along in chapters 6, 7 and 8 and do the exercises.  Add the exercises to your git repository and tag them as Week3. Use any extra time you have to play around with what we've learned and asked questions about anything you don't understand.
